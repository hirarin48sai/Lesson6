class UsersController < ApplicationController

  def index
    @user = User.find_by(id:current_user.id)
    @users = User.all.order(name: :asc)
    @book_new = Book.new

  end

  def show
    
    @book = Book.new
    @books = Book.all
    @user = User.find(params[:id])
    
  end

  def edit
    @user = User.find(params[:id])
    redirect_to user_path(current_user) unless @user.id == current_user.id
    
  end

  def update
    @user = User.find(params[:id])
    if @user.update(update_params)
       flash[:notice] = "You have updated user successfully."
       redirect_to user_path(@user)
    else
       render :edit
    end
  end


 private
 
  
 def update_params
  params.require(:user).permit(:name,:profile_image,:introduction)
 end

 

end
