class BooksController < ApplicationController


  def create
    @book_new = Book.new(book_params)
    @book_new.user_id = current_user.id
    if @book_new.save
      flash[:notice] = "You have created book successfully."
      redirect_to book_path(@book_new)
    else
      @user = User.find_by(id:current_user.id)
      @books = Book.all
      render :index
    end
  end

  def index
    @user = User.find_by(id:current_user.id)
    @book_new = Book.new
    @books = Book.all
  end

  def show
    @user = User.find_by(id:current_user.id)
    @book_new = Book.new
    @book = Book.find(params[:id])
    
  end

  def edit
    @user = User.find_by(id:current_user.id)
    
    @book = Book.find(params[:id])
    redirect_to books_path unless @book.user_id == current_user.id
  end

  def update
    @book = Book.find(params[:id])
     if @book.update(update_params)
       flash[:notice] = "You have updated book successfully."
       redirect_to book_path(@book)
     else
       render:edit
     end
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
    redirect_to books_path
  end

  private

  def book_params
    params.require(:book).permit(:title,:body)
  end

  def update_params
    params.require(:book).permit(:title,:body)
  end


end


