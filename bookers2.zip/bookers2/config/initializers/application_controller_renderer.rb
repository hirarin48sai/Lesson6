# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'aba66d3133b98ad27a6637018232721f5bb0d4944a622967a2ff1242a256f5213e4a3369fa5c8832b323646903992a3e5078204dd3e6ebaec64537e31b930d9d'